package com.andro.myappyy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Eventss_display extends AppCompatActivity {

    String s1,s2,s3,s4,s5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventss_display);
    }
}
