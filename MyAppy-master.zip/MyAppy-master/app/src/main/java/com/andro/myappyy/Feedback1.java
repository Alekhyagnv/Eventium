package com.andro.myappyy;

public class Feedback1 {
    public String hno;
    public String subj;
    public String email;

    public String getFeedback() {
        return feedback;
    }

    public void setSubj(String subj) {
        this.subj = subj;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public String feedback;

    public String getFeed() {
        return feed;
    }

    public void setFeed(String feed) {
        this.feed = feed;
    }

    public String feed;

    public Feedback1() {
    }

    public String getHno() {
        return hno;
    }

    public void setHno(String hno) {
        this.hno = hno;
    }

    public String getSubj() {
        return subj;
    }
}