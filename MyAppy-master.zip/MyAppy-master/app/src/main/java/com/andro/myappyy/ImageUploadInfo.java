package com.andro.myappyy;

public class ImageUploadInfo {
    String image;
    public  ImageUploadInfo()
    {

    }

    public ImageUploadInfo(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
