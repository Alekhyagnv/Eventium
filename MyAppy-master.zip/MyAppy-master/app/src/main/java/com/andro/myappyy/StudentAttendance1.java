package com.andro.myappyy;

class StudentAttendence1 {


    private String Name;
    private String H_No;
    private String Branch;
    private String Year;
    private String present;

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    private String ename;

    public StudentAttendence1() {
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getH_No() {
        return H_No;
    }

    public void setH_No(String h_No) {
        H_No = h_No;
    }

    public String getBranch() {
        return Branch;
    }

    public void setBranch(String branch) {
        Branch = branch;
    }

    public String getYear() {
        return Year;
    }

    public void setYear(String year) {
        Year = year;
    }

    public String getPresent() {
        return present;
    }

    public void setPresent(String present) {
        this.present = present;
    }

}

